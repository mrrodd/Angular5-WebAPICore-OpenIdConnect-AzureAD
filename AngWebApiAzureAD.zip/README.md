# Angular5-WebAPICore-OpenIdConnect-AzureAD
Sample of Token Based authentication with Angular5, WebAPI Core, Open Id Connect, Azure AD + samples of requests using Angular 5 HttpInterceptors

Added compatibility with Angular 5.2.8+, token was unreadable since this version
